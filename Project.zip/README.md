# HarmonyOS Control Panel Services  (com.harmonyos.controlpanel)

A HarmonyOS-style Control Panel for Android, drawn as an overlay above any app.

## Build
GitHub Actions: put `.github/workflows/build.yml` (included) in the repo and push. The debug APK is uploaded as an artifact.
Locally: `gradle assembleDebug` (Gradle 8.5, JDK 17).

## Setup (in the app)
1. Enable the **accessibility service** (Android 13+: App info -> ⋮ -> *Allow restricted settings* first).
2. Allow **Modify system settings** and **Do Not Disturb access**.
3. Optional: notification access (real media info), Bluetooth/location permission (paired devices, Wi-Fi name).
4. Optional, for direct airplane/location/dark-mode/power-saving toggles:
   `adb shell pm grant com.harmonyos.controlpanel android.permission.WRITE_SECURE_SETTINGS`

## Open the panel
Pull down from the top-right edge - Quick Settings tile "Control Panel" - accessibility button.

## Notes
- The blurred backdrop is a real screenshot (accessibility `takeScreenshot`, Android 11+); older versions get a teal gradient.
- Android blocks normal apps from silently toggling Wi-Fi/Bluetooth(13+)/mobile data/hotspot/NFC, so those open the matching system panel.
