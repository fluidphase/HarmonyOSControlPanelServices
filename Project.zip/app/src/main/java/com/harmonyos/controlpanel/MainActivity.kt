package com.harmonyos.controlpanel

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = HmBlue)) { SetupScreen() }
        }
    }
}

private data class Step(
    val title: String, val desc: String, val ok: Boolean,
    val optional: Boolean, val button: String, val action: () -> Unit
)

@Composable
private fun SetupScreen() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }
    val refreshKey = tick

    fun open(a: String, pkg: Boolean = false) {
        val i = Intent(a); if (pkg) i.data = Uri.parse("package:${ctx.packageName}")
        try { ctx.startActivity(i) } catch (_: Throwable) { try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Throwable) {} }
    }

    val enabledA11y = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
    val a11yOk = enabledA11y.contains(ctx.packageName) && enabledA11y.contains("ControlPanelService")
    val btPerm = Build.VERSION.SDK_INT < 31 || ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    val locPerm = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val secureOk = ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED
    val adb = "adb shell pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS"

    val steps = listOf(
        Step("Accessibility service", "Required. Draws the panel over every app, grabs the screen behind it for the blur, and powers lock / screenshot / power-menu actions. On Android 13+ you may first need App info -> menu -> Allow restricted settings.",
            a11yOk, false, "Open") { open(Settings.ACTION_ACCESSIBILITY_SETTINGS) },
        Step("Modify system settings", "Lets the panel change brightness, auto-rotate, auto-brightness and screen timeout.",
            Settings.System.canWrite(ctx), false, "Allow") { open(Settings.ACTION_MANAGE_WRITE_SETTINGS, true) },
        Step("Do Not Disturb access", "Needed for DND, silent mode and the Sleep / Movie scenes.",
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted,
            false, "Allow") { open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) },
        Step("Notification access", "Optional. Lets the media card show the real title, artist and artwork of what's playing.",
            NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName), true, "Allow") {
            open("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
        },
        Step("Bluetooth & location permissions", "Optional. Shows your paired devices in Super Device and the real Wi-Fi name.",
            btPerm && locPerm, true, "Grant") {
            val list = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 31) list += Manifest.permission.BLUETOOTH_CONNECT
            permLauncher.launch(list.toTypedArray())
        },
        Step("Secure settings (adb)", "Optional. Lets airplane mode, location, dark mode and power saving switch directly instead of opening Settings. Run on a PC:\n$adb",
            secureOk, true, "Copy command") {
            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("adb", adb))
        }
    )

    Column(
        Modifier.fillMaxSize().background(Color(0xFFF1F3F5)).verticalScroll(rememberScrollState())
            .statusBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.hmos_logo), null, Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)))
            Spacer(Modifier.width(14.dp))
            Column {
                Text("HarmonyOS Control Panel Services", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF111111))
                Text("com.harmonyos.controlpanel", fontSize = 12.sp, color = Color(0x99000000))
            }
        }

        Button(
            onClick = {
                val s = ControlPanelService.instance
                if (s == null) open(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                else {
                    (ctx as? Activity)?.moveTaskToBack(true)
                    Handler(Looper.getMainLooper()).postDelayed({ s.showPanel() }, 450)
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(25.dp),
            colors = ButtonDefaults.buttonColors(containerColor = HmBlue)
        ) { Text(if (a11yOk) "Open Control Panel" else "Enable the service first", fontSize = 15.sp) }

        Text("Pull down from the top-right edge, tap the Control Panel quick-settings tile, or use the accessibility button. Changes below apply the next time the panel opens.",
            fontSize = 12.sp, color = Color(0x99000000))

        AnimationSettings()
        LayoutSettings()
        MediaSettings()

        SectionCard("Behaviour & stability") {
            PBool("Top-edge pull-down", "edge", true, "Pull down from the top-right edge to open")
            PBool("Haptic feedback", "haptics", true)
            PBool("Safe mode", "safe_mode", false, "No animations and no screenshot blur. Turns itself on if the panel ever crashes while opening.")
        }

        steps.forEach { s ->
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(s.title + if (s.optional) "  (optional)" else "", fontSize = 14.sp, fontWeight = FontWeight.Medium,
                        color = Color(0xFF111111), modifier = Modifier.weight(1f))
                    Text(if (s.ok) "Done" else "Not set", fontSize = 12.sp, color = if (s.ok) Color(0xFF1E9E55) else Color(0xFFB3261E))
                }
                Spacer(Modifier.height(4.dp))
                Text(s.desc, fontSize = 12.sp, color = Color(0x99000000))
                if (!s.ok) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = s.action, shape = RoundedCornerShape(18.dp)) { Text(s.button, color = HmBlue) }
                }
            }
        }

        OutlinedButton(
            onClick = {
                Prefs.sp(ctx).edit().clear().apply()
                (ctx as? Activity)?.recreate()
            },
            shape = RoundedCornerShape(18.dp)
        ) { Text("Reset all settings to default", color = Color(0xFFB3261E)) }
        Spacer(Modifier.height(24.dp))
    }
}
