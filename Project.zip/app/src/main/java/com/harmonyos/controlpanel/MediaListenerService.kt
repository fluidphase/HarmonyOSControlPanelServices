package com.harmonyos.controlpanel

import android.service.notification.NotificationListenerService

/** Empty on purpose: enabling it grants permission to read active media sessions (title, artist, artwork). */
class MediaListenerService : NotificationListenerService()
