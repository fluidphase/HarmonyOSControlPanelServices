package com.harmonyos.controlpanel

import android.content.Context
import android.os.Build
import androidx.compose.runtime.compositionLocalOf

val SECTION_IDS = listOf("header", "media", "toggles", "super", "scenes", "devices")
val SECTION_LABELS = linkedMapOf(
    "header" to "Clock, date & shortcuts",
    "media" to "Media player + Wi-Fi / Bluetooth",
    "toggles" to "Quick toggles & sliders",
    "super" to "Super Device",
    "scenes" to "Scenes",
    "devices" to "Smart devices"
)
val TILE_LABELS = linkedMapOf(
    "torch" to "Flashlight", "sound" to "Sound", "rotate" to "Auto-rotate", "hotspot" to "Hotspot",
    "location" to "Location", "airplane" to "Airplane", "dnd" to "Do not disturb", "nfc" to "NFC",
    "eye" to "Eye comfort", "dark" to "Dark mode", "data" to "Mobile data", "saver" to "Power saving",
    "timeout" to "Screen timeout", "autobright" to "Auto brightness", "lock" to "Lock screen",
    "shot" to "Screenshot", "power" to "Power menu", "camera" to "Camera"
)
val DEFAULT_QUICK = listOf("torch", "sound", "rotate", "hotspot", "location", "airplane")

data class AnimPreset(
    val name: String, val desc: String,
    val scale0: Float, val ty0: Float, val tx0: Float,
    val damping: Float, val stiffness: Float, val stagger: Long
)

object AnimPresets {
    val all = listOf(
        AnimPreset("HarmonyOS", "Springy size-up, the stock feel", 0.78f, 40f, 0f, 0.68f, 320f, 55L),
        AnimPreset("Soft Fade", "Gentle fade with a tiny rise", 0.96f, 12f, 0f, 1.0f, 180f, 25L),
        AnimPreset("Slide Down", "Cards drop in from the top", 1f, -70f, 0f, 0.8f, 300f, 40L),
        AnimPreset("Bounce", "Big, bouncy pop from below", 0.5f, 90f, 0f, 0.38f, 260f, 70L),
        AnimPreset("Slide In", "Cards glide in from the right", 0.96f, 0f, 140f, 0.8f, 340f, 45L),
        AnimPreset("Zoom Burst", "Fast zoom from the centre", 0.25f, 0f, 0f, 0.6f, 450f, 30L),
        AnimPreset("Cascade", "Slow, one-by-one waterfall", 0.9f, 30f, 0f, 0.9f, 260f, 110L)
    )
    fun get(name: String): AnimPreset = all.firstOrNull { it.name == name } ?: all[0]
}

data class AnimConfig(
    val enabled: Boolean = true,
    val preset: String = "HarmonyOS",
    val speed: Float = 1f,
    val pressBounce: Boolean = true,
    val toggleBounce: Boolean = true
)

data class LayoutConfig(
    val order: List<String> = SECTION_IDS,
    val quick: List<String> = DEFAULT_QUICK,
    val widthDp: Int = 380,
    val position: String = "Right",
    val radiusDp: Int = 22,
    val cardAlpha: Float = 0.64f,
    val outline: Boolean = false,
    val spacingDp: Int = 8,
    val tileDp: Int = 46,
    val dimPercent: Int = 22,
    val fallbackDim: Int = 50,
    val showStatus: Boolean = true,
    val showBrightness: Boolean = true,
    val showVolume: Boolean = true,
    val showEyeSlider: Boolean = true,
    val showDate: Boolean = true,
    val timeFormat: String = "System",
    val startExpanded: Boolean = false
)

data class MediaConfig(
    val show: Boolean = true,
    val style: String = "Standard",
    val showArt: Boolean = true,
    val showBadge: Boolean = true,
    val showCast: Boolean = true,
    val artShape: String = "Rounded",
    val artSizeDp: Int = 46,
    val demoFallback: Boolean = true,
    val hideWhenIdle: Boolean = false,
    val heightDp: Int = 138
)

data class PanelConfig(val anim: AnimConfig, val layout: LayoutConfig, val media: MediaConfig, val safe: Boolean)

val LocalAnim = compositionLocalOf { AnimConfig() }
val LocalLayout = compositionLocalOf { LayoutConfig() }

fun loadSectionOrder(ctx: Context): List<String> {
    val saved = (Prefs.str(ctx, "ly_order", null) ?: "").split(",").map { it.trim() }.filter { it in SECTION_IDS }.distinct()
    return saved + SECTION_IDS.filter { it !in saved }
}

fun loadQuick(ctx: Context): List<String> {
    val raw = Prefs.str(ctx, "ly_quick", null) ?: return DEFAULT_QUICK
    val l = raw.split(",").map { it.trim() }.filter { it in TILE_LABELS.keys }.distinct()
    return if (l.size >= 3) l.take(7) else DEFAULT_QUICK
}

object ConfigStore {
    fun safe(ctx: Context) = Prefs.bool(ctx, "safe_mode", false)

    fun blurEnabled(ctx: Context) =
        Build.VERSION.SDK_INT >= 30 && !safe(ctx) && (Prefs.str(ctx, "backdrop", "Blur") ?: "Blur") == "Blur"

    /** scale, radius, passes */
    fun blurParams(ctx: Context): Triple<Int, Int, Int> = when (Prefs.str(ctx, "blur", "Medium")) {
        "Light" -> Triple(6, 3, 2)
        "Strong" -> Triple(14, 5, 3)
        else -> Triple(10, 4, 3)
    }

    fun load(ctx: Context): PanelConfig {
        val safe = safe(ctx)
        val anim = AnimConfig(
            enabled = !safe && Prefs.bool(ctx, "anim_on", true),
            preset = Prefs.str(ctx, "anim_preset", "HarmonyOS") ?: "HarmonyOS",
            speed = Prefs.int(ctx, "anim_speed", 100) / 100f,
            pressBounce = Prefs.bool(ctx, "anim_press", true),
            toggleBounce = Prefs.bool(ctx, "anim_toggle", true)
        )
        val hidden = (Prefs.str(ctx, "ly_hide", "") ?: "").split(",").filter { it.isNotBlank() }.toSet()
        val layout = LayoutConfig(
            order = loadSectionOrder(ctx).filter { it !in hidden },
            quick = loadQuick(ctx),
            widthDp = Prefs.int(ctx, "ly_width", 380),
            position = Prefs.str(ctx, "ly_pos", "Right") ?: "Right",
            radiusDp = Prefs.int(ctx, "ly_radius", 22),
            cardAlpha = Prefs.int(ctx, "ly_alpha", 64) / 100f,
            outline = Prefs.bool(ctx, "ly_outline", false),
            spacingDp = Prefs.int(ctx, "ly_spacing", 8),
            tileDp = Prefs.int(ctx, "ly_tile", 46),
            dimPercent = Prefs.int(ctx, "ly_dim", 22),
            fallbackDim = Prefs.int(ctx, "ly_fallback_dim", 50),
            showStatus = Prefs.bool(ctx, "ly_status", true),
            showBrightness = Prefs.bool(ctx, "ly_bright", true),
            showVolume = Prefs.bool(ctx, "ly_vol", true),
            showEyeSlider = Prefs.bool(ctx, "ly_eye", true),
            showDate = Prefs.bool(ctx, "ly_date", true),
            timeFormat = Prefs.str(ctx, "ly_timefmt", "System") ?: "System",
            startExpanded = Prefs.bool(ctx, "ly_expanded", false)
        )
        val media = MediaConfig(
            show = Prefs.bool(ctx, "md_show", true),
            style = Prefs.str(ctx, "md_style", "Standard") ?: "Standard",
            showArt = Prefs.bool(ctx, "md_art", true),
            showBadge = Prefs.bool(ctx, "md_badge", true),
            showCast = Prefs.bool(ctx, "md_cast", true),
            artShape = Prefs.str(ctx, "md_shape", "Rounded") ?: "Rounded",
            artSizeDp = Prefs.int(ctx, "md_artsize", 46),
            demoFallback = Prefs.bool(ctx, "md_demo", true),
            hideWhenIdle = Prefs.bool(ctx, "md_hide", false),
            heightDp = Prefs.int(ctx, "md_height", 138)
        )
        return PanelConfig(anim, layout, media, safe)
    }
}
