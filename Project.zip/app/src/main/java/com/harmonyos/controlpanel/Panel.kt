@file:OptIn(ExperimentalFoundationApi::class)

package com.harmonyos.controlpanel

import android.content.Context
import android.media.AudioManager
import android.text.format.DateFormat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun timeFmt(ctx: Context, mode: String, ampm: Boolean): String = when (mode) {
    "24-hour" -> "HH:mm"
    "12-hour" -> if (ampm) "h:mm a" else "h:mm"
    else -> if (DateFormat.is24HourFormat(ctx)) "HH:mm" else if (ampm) "h:mm a" else "h:mm"
}

@Composable
fun PanelRoot(
    c: SystemController,
    cfg: PanelConfig,
    bg: ImageBitmap?,
    statusDp: Dp,
    closeSignal: Int,
    onRequestClose: () -> Unit,
    onClosed: () -> Unit,
    onStable: () -> Unit
) {
    val lay = cfg.layout
    val anim = cfg.anim
    val dark = isSystemInDarkTheme()
    val p = remember(dark, lay.cardAlpha) { Palette(dark, lay.cardAlpha) }
    val sp = anim.speed.coerceIn(0.4f, 2.5f)
    var shown by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { shown = true }
    LaunchedEffect(closeSignal) {
        if (closeSignal > 0) {
            shown = false
            if (anim.enabled) delay((300 / sp).toLong())
            onClosed()
        }
    }
    LaunchedEffect(Unit) { delay(900); onStable() }
    // state is read on a worker thread so the first frame never waits for it
    LaunchedEffect(Unit) { while (true) { withContext(Dispatchers.Default) { c.refresh() }; delay(1000) } }

    val bgSpec: AnimationSpec<Float> = if (anim.enabled) tween((320 / sp).toInt()) else snap()
    val bgAlpha by animateFloatAsState(if (shown) 1f else 0f, bgSpec, label = "bgA")
    val zoomSpec: AnimationSpec<Float> = if (anim.enabled) tween((450 / sp).toInt(), easing = FastOutSlowInEasing) else snap()
    val bgScale by animateFloatAsState(if (shown || !anim.enabled) 1f else 1.06f, zoomSpec, label = "bgS")

    val tiles = c.allTiles()
    val quick = lay.quick.mapNotNull { tiles[it] }
    val extras = tiles.values.filter { it.id !in lay.quick }

    CompositionLocalProvider(LocalAnim provides anim, LocalLayout provides lay) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val panelW = minOf(lay.widthDp.dp, maxWidth - 24.dp)
            val inner = panelW - 28.dp
            val tileSize = minOf(lay.tileDp.dp, inner / quick.size.coerceAtLeast(1) - 2.dp)
            val alignment = when (lay.position) {
                "Left" -> Alignment.TopStart
                "Center" -> Alignment.TopCenter
                else -> Alignment.TopEnd
            }

            if (bg != null) {
                Image(
                    bg, null,
                    Modifier.fillMaxSize().graphicsLayer { alpha = bgAlpha; scaleX = bgScale; scaleY = bgScale },
                    contentScale = ContentScale.Crop, filterQuality = FilterQuality.Medium
                )
                val wash = ((if (dark) lay.dimPercent + 13 else lay.dimPercent) / 100f).coerceIn(0f, 0.95f)
                Box(Modifier.fillMaxSize().background((if (dark) Color.Black else Color.White).copy(alpha = wash * bgAlpha)))
            } else {
                // no screenshot: plain translucent black
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = (lay.fallbackDim / 100f).coerceIn(0f, 1f) * bgAlpha)))
            }

            // tap outside / swipe up to dismiss
            Box(
                Modifier.fillMaxSize()
                    .pointerInput(Unit) { detectTapGestures { onRequestClose() } }
                    .pointerInput(Unit) {
                        var acc = 0f
                        detectVerticalDragGestures(
                            onDragStart = { acc = 0f },
                            onDragEnd = { if (acc < -60f) onRequestClose() }
                        ) { ch, dy -> ch.consume(); acc += dy }
                    }
            )

            if (lay.showStatus) StatusRow(c, p, lay, statusDp, bgAlpha)

            Column(
                Modifier
                    .align(alignment)
                    .padding(horizontal = 12.dp)
                    .width(panelW)
                    .padding(top = statusDp + 6.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(lay.spacingDp.dp)
            ) {
                lay.order.forEachIndexed { idx, id ->
                    when (id) {
                        "header" -> Header(c, p, lay, Modifier.popIn(shown, idx))
                        "media" -> MediaSection(c, p, cfg, shown, idx)
                        "toggles" -> TogglesCard(c, p, lay, quick, extras, tileSize, shown, idx)
                        "super" -> SuperCard(c, p, Modifier.popIn(shown, idx))
                        "scenes" -> ScenesCard(c, p, Modifier.popIn(shown, idx))
                        "devices" -> DevicesRow(c, p, lay, shown, idx)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusRow(c: SystemController, p: Palette, lay: LayoutConfig, h: Dp, alpha: Float) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val fmt = timeFmt(ctx, lay.timeFormat, false)
    Row(
        Modifier.fillMaxWidth().height(h).padding(horizontal = 16.dp).graphicsLayer { this.alpha = alpha },
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End
    ) {
        if (c.wifiOn) Icon(Icons.Rounded.Wifi, null, tint = p.text, modifier = Modifier.size(13.dp))
        if (c.btOn) Icon(Icons.Rounded.Bluetooth, null, tint = p.text, modifier = Modifier.size(13.dp).padding(start = 3.dp))
        Spacer(Modifier.width(6.dp))
        Canvas(Modifier.size(20.dp, 10.dp)) {
            val stroke = 1.dp.toPx()
            drawRoundRect(p.text.copy(alpha = 0.55f), size = size, cornerRadius = CornerRadius(3.dp.toPx()), style = Stroke(stroke))
            drawRoundRect(
                if (c.charging) Color(0xFF30D158) else p.text, Offset(2.dp.toPx(), 2.dp.toPx()),
                Size((size.width - 4.dp.toPx()) * c.battery / 100f, size.height - 4.dp.toPx()), CornerRadius(1.5.dp.toPx())
            )
        }
        Spacer(Modifier.width(4.dp))
        Text("${c.battery}%", fontSize = 11.sp, color = p.text)
        Spacer(Modifier.width(8.dp))
        Text(SimpleDateFormat(fmt, Locale.getDefault()).format(Date(now)), fontSize = 12.sp, color = p.text)
    }
}

@Composable
private fun Header(c: SystemController, p: Palette, lay: LayoutConfig, modifier: Modifier) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val fmt = timeFmt(ctx, lay.timeFormat, true)
    Row(modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(SimpleDateFormat(fmt, Locale.getDefault()).format(Date(now)), fontSize = 30.sp, fontWeight = FontWeight.Medium, color = p.text)
            if (lay.showDate) Text(SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date(now)), fontSize = 12.sp, color = p.sub)
        }
        IconTap(Icons.Rounded.EditNote, p.text, c::openApp)
        IconTap(Icons.Rounded.Settings, p.text, c::openSystemSettings)
    }
}

@Composable
private fun MediaSection(c: SystemController, p: Palette, cfg: PanelConfig, shown: Boolean, idx: Int) {
    val m = cfg.media
    val gap = cfg.layout.spacingDp.dp
    val showCard = m.show && !(m.hideWhenIdle && !c.mediaReal)
    if (showCard) {
        Row(Modifier.fillMaxWidth().height(m.heightDp.dp), horizontalArrangement = Arrangement.spacedBy(gap)) {
            MediaCard(c, p, m, Modifier.weight(1f).fillMaxHeight().popIn(shown, idx))
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(gap)) {
                ConnTile(Icons.Rounded.Wifi, c.wifiOn, c.wifiName, p, c::toggleWifi, c::openWifi,
                    Modifier.weight(1f).fillMaxWidth().popIn(shown, idx + 1))
                ConnTile(Icons.Rounded.Bluetooth, c.btOn, "Bluetooth", p, c::toggleBt, c::openBt,
                    Modifier.weight(1f).fillMaxWidth().popIn(shown, idx + 1))
            }
        }
    } else {
        Row(Modifier.fillMaxWidth().height(68.dp), horizontalArrangement = Arrangement.spacedBy(gap)) {
            ConnTile(Icons.Rounded.Wifi, c.wifiOn, c.wifiName, p, c::toggleWifi, c::openWifi,
                Modifier.weight(1f).fillMaxHeight().popIn(shown, idx))
            ConnTile(Icons.Rounded.Bluetooth, c.btOn, "Bluetooth", p, c::toggleBt, c::openBt,
                Modifier.weight(1f).fillMaxHeight().popIn(shown, idx + 1))
        }
    }
}

@Composable
private fun MediaCard(c: SystemController, p: Palette, m: MediaConfig, modifier: Modifier) {
    val title = if (c.mediaReal) c.mediaTitle ?: "" else if (m.demoFallback) "Dream It Possible" else "Nothing playing"
    val artist = if (c.mediaReal) c.mediaArtist ?: "" else if (m.demoFallback) "Delacey" else ""
    val art = if (c.mediaReal) c.mediaArt else null
    val artImg = remember(art) { art?.asImageBitmap() }
    val large = m.style == "Large art"
    val minimal = m.style == "Minimal"
    val fg = if (large) Color.White else p.text
    val fgSub = if (large) Color.White.copy(alpha = 0.75f) else p.sub
    val demoBrush = Brush.linearGradient(listOf(Color(0xFF7A1E1E), Color(0xFF1B1B2F), Color(0xFFD64545)))

    GlassCard(p, modifier) {
        if (large) {
            if (artImg != null) Image(artImg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Box(Modifier.fillMaxSize().background(demoBrush))
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x22000000), Color(0xB0000000)))))
        }
        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                if (!large && !minimal && m.showArt) {
                    val shape = when (m.artShape) {
                        "Circle" -> CircleShape
                        "Square" -> RoundedCornerShape(2.dp)
                        else -> RoundedCornerShape(9.dp)
                    }
                    Box(Modifier.size(m.artSizeDp.dp)) {
                        if (artImg != null) {
                            Image(artImg, null, Modifier.fillMaxSize().clip(shape), contentScale = ContentScale.Crop)
                        } else {
                            Box(Modifier.fillMaxSize().clip(shape).background(demoBrush), contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(22.dp))
                            }
                        }
                        if (m.showBadge) {
                            Box(
                                Modifier.align(Alignment.BottomEnd).offset(4.dp, 4.dp).size(16.dp).clip(CircleShape).background(p.accent),
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Rounded.MusicNote, null, tint = Color.White, modifier = Modifier.size(10.dp)) }
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                if (m.showCast) IconTap(Icons.Rounded.Cast, fg.copy(alpha = 0.8f), c::openCast, 30.dp, 17.dp)
            }
            Column {
                Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (artist.isNotEmpty()) Text(artist, fontSize = 11.sp, color = fgSub, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconTap(Icons.Rounded.SkipPrevious, fg, c::prevTrack, 36.dp, 22.dp)
                IconTap(if (c.isPlayingUi) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, fg, c::playPause, 36.dp, 24.dp)
                IconTap(Icons.Rounded.SkipNext, fg, c::nextTrack, 36.dp, 22.dp)
            }
        }
    }
}

@Composable
private fun ConnTile(
    icon: ImageVector, active: Boolean, title: String, p: Palette,
    onToggle: () -> Unit, onOpen: () -> Unit, modifier: Modifier
) {
    GlassCard(p, modifier, onClick = onOpen) {
        Row(Modifier.fillMaxSize().padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            CircleToggle(icon, active, p, 38.dp, onToggle)
            Spacer(Modifier.width(9.dp))
            Text(title, fontSize = 12.sp, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        }
        Canvas(Modifier.align(Alignment.BottomEnd).padding(6.dp).size(6.dp)) {
            val path = Path().apply { moveTo(size.width, 0f); lineTo(size.width, size.height); lineTo(0f, size.height); close() }
            drawPath(path, p.text.copy(alpha = 0.55f))
        }
    }
}

@Composable
private fun TogglesCard(
    c: SystemController, p: Palette, lay: LayoutConfig,
    quick: List<TileModel>, extras: List<TileModel>, tileSize: Dp, shown: Boolean, idx: Int
) {
    val anim = LocalAnim.current
    var expanded by remember { mutableStateOf(lay.startExpanded) }
    val enter: EnterTransition = if (anim.enabled) expandVertically(spring(stiffness = Spring.StiffnessMediumLow)) + fadeIn(tween(200)) else EnterTransition.None
    val exit: ExitTransition = if (anim.enabled) shrinkVertically(tween(220)) + fadeOut(tween(150)) else ExitTransition.None

    GlassCard(p, Modifier.fillMaxWidth().popIn(shown, idx)) {
        Column(Modifier.padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 2.dp)) {
            if (quick.isNotEmpty()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    quick.forEach { t -> CircleToggle(t.icon, t.active, p, tileSize, t.onClick, t.onLong) }
                }
            }
            if (lay.showBrightness) {
                if (quick.isNotEmpty()) Spacer(Modifier.height(14.dp))
                HmSlider(c.brightness, c::applyBrightness, p, Icons.Rounded.BrightnessLow, Icons.Rounded.BrightnessHigh)
            }
            AnimatedVisibility(expanded, enter = enter, exit = exit) {
                Column {
                    Spacer(Modifier.height(16.dp))
                    extras.chunked(4).forEachIndexed { row, rowTiles ->
                        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                            rowTiles.forEachIndexed { i, t ->
                                Column(
                                    Modifier.weight(1f).popIn(expanded, row * 4 + i),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    CircleToggle(t.icon, t.active, p, 46.dp, t.onClick, t.onLong)
                                    Spacer(Modifier.height(4.dp))
                                    Text(t.label, fontSize = 10.sp, color = p.sub, maxLines = 1,
                                        overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                                }
                            }
                            repeat(4 - rowTiles.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    if (lay.showVolume) {
                        HmSlider(c.volMusic, { c.setVolume(AudioManager.STREAM_MUSIC, it) }, p, Icons.Rounded.MusicNote, Icons.Rounded.VolumeUp)
                        HmSlider(c.volRing, { c.setVolume(AudioManager.STREAM_RING, it) }, p, Icons.Rounded.NotificationsActive, Icons.Rounded.VolumeUp)
                        HmSlider(c.volAlarm, { c.setVolume(AudioManager.STREAM_ALARM, it) }, p, Icons.Rounded.Alarm, Icons.Rounded.VolumeUp)
                    }
                    if (lay.showEyeSlider) {
                        HmSlider(if (c.eyeOn) c.eyeStrength else 0f, c::applyEyeStrength, p, Icons.Rounded.RemoveRedEye, Icons.Rounded.WbSunny)
                    }
                }
            }
            HandleBar(p, { expanded = false }, { expanded = true }, { expanded = !expanded })
        }
    }
}

@Composable
private fun SuperCard(c: SystemController, p: Palette, modifier: Modifier) {
    GlassCard(p, modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Super Device", fontSize = 12.sp, color = p.text, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                IconTap(Icons.Rounded.TrackChanges, p.text.copy(alpha = 0.8f), c::openBt, 28.dp, 18.dp)
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                c.devices.forEach { d ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        CircleToggle(d.icon, d.active, p, 38.dp, d.onClick)
                        Spacer(Modifier.height(5.dp))
                        Text(d.name, fontSize = 10.sp, color = p.text.copy(alpha = 0.85f), maxLines = 1,
                            overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}

@Composable
private fun ScenesCard(c: SystemController, p: Palette, modifier: Modifier) {
    var open by remember { mutableStateOf(false) }
    GlassCard(p, modifier.fillMaxWidth()) {
        Column(Modifier.padding(start = 8.dp, end = 8.dp, top = 8.dp)) {
            val all = listOf(
                "Home" to Icons.Rounded.MeetingRoom, "Happy Day" to Icons.Rounded.FreeBreakfast,
                "Leave Home" to Icons.Rounded.DirectionsWalk, "Sleep" to Icons.Rounded.Bedtime,
                "Movie" to Icons.Rounded.Movie, "Party" to Icons.Rounded.Celebration
            )
            val rows = if (open) all.chunked(2) else all.take(2).chunked(2)
            rows.forEach { pair ->
                Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    pair.forEach { (name, icon) ->
                        SceneButton(name, icon, name in c.scenes, p, Modifier.weight(1f)) { c.toggleScene(name) }
                    }
                }
            }
            HandleBar(p, { open = false }, { open = true }, { open = !open })
        }
    }
}

@Composable
private fun SceneButton(name: String, icon: ImageVector, active: Boolean, p: Palette, modifier: Modifier, onClick: () -> Unit) {
    val ms = if (LocalAnim.current.enabled) 240 else 0
    val bg by animateColorAsState(
        if (active) p.accent.copy(alpha = 0.9f) else p.tileOff.copy(alpha = if (p.dark) 0.18f else 0.08f), tween(ms), label = "sc"
    )
    Row(
        modifier.height(42.dp).pressScale(onClick, null, 0.95f).clip(RoundedCornerShape(14.dp)).background(bg).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (active) Color.White else p.text.copy(alpha = 0.85f), modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(name, fontSize = 12.sp, color = if (active) Color.White else p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun DevicesRow(c: SystemController, p: Palette, lay: LayoutConfig, shown: Boolean, idx: Int) {
    Row(Modifier.fillMaxWidth().height(96.dp), horizontalArrangement = Arrangement.spacedBy(lay.spacingDp.dp)) {
        DeviceCard("AI Full view Camera", if (c.camOn) "Online" else "Offline", c.camOn, true, p, c::toggleCam,
            Modifier.weight(1f).fillMaxHeight().popIn(shown, idx))
        DeviceCard("Smart Air Purifier", if (c.purifierOn) "On" else "Off", c.purifierOn, false, p, c::togglePurifier,
            Modifier.weight(1f).fillMaxHeight().popIn(shown, idx + 1))
    }
}

@Composable
private fun DeviceCard(title: String, status: String, on: Boolean, camera: Boolean, p: Palette, onPower: () -> Unit, modifier: Modifier) {
    GlassCard(p, modifier) {
        Column(Modifier.padding(start = 12.dp, top = 10.dp, end = 8.dp)) {
            Text(title, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("$status | Living room", fontSize = 9.sp, color = p.sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Canvas(Modifier.align(Alignment.BottomStart).padding(start = 22.dp, bottom = 8.dp).size(24.dp, 34.dp)) {
            val body = Color.White.copy(alpha = if (p.dark) 0.9f else 0.95f)
            if (camera) {
                drawRoundRect(body, Offset(size.width * 0.15f, size.height * 0.1f), Size(size.width * 0.7f, size.height * 0.9f), CornerRadius(size.width * 0.3f))
                drawCircle(Color(0xFF2B2F36), size.width * 0.17f, Offset(size.width / 2, size.height * 0.4f))
            } else {
                drawRoundRect(body, Offset(0f, size.height * 0.05f), Size(size.width, size.height * 0.95f), CornerRadius(size.width * 0.3f))
                drawCircle(Color(0xFFB8BEC8), size.width * 0.28f, Offset(size.width / 2, size.height * 0.3f))
            }
        }
        val ms = if (LocalAnim.current.enabled) 240 else 0
        val bg by animateColorAsState(if (on) p.accent else p.tileOff, tween(ms), label = "pw")
        Box(
            Modifier.align(Alignment.BottomEnd).padding(8.dp).size(28.dp).pressScale(onPower, null, 0.85f).clip(CircleShape).background(bg),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.PowerSettingsNew, null, tint = if (on) Color.White else p.iconOff, modifier = Modifier.size(15.dp)) }
    }
}
