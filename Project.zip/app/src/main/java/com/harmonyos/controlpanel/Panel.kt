@file:OptIn(ExperimentalFoundationApi::class)

package com.harmonyos.controlpanel

import android.media.AudioManager
import android.text.format.DateFormat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PanelRoot(
    c: SystemController,
    bg: ImageBitmap?,
    statusDp: Dp,
    closeSignal: Int,
    onRequestClose: () -> Unit,
    onClosed: () -> Unit
) {
    val dark = isSystemInDarkTheme()
    val p = remember(dark) { Palette(dark) }
    var shown by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    var scenesOpen by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { shown = true }
    LaunchedEffect(closeSignal) {
        if (closeSignal > 0) { shown = false; delay(320); onClosed() }
    }
    LaunchedEffect(Unit) { while (true) { c.refresh(); delay(1000) } }

    val bgAlpha by animateFloatAsState(if (shown) 1f else 0f, tween(320), label = "bgA")
    val bgScale by animateFloatAsState(if (shown) 1f else 1.06f, tween(450, easing = FastOutSlowInEasing), label = "bgS")

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 600.dp
        val panelW = if (wide) 380.dp else maxWidth - 24.dp

        // blurred screenshot (or the HarmonyOS-teal fallback)
        if (bg != null) {
            Image(
                bg, null, Modifier.fillMaxSize().graphicsLayer { alpha = bgAlpha; scaleX = bgScale; scaleY = bgScale },
                contentScale = ContentScale.Crop, filterQuality = FilterQuality.Medium
            )
            Box(Modifier.fillMaxSize().background((if (dark) Color.Black else Color.White).copy(alpha = (if (dark) 0.35f else 0.22f) * bgAlpha)))
        } else {
            // no screenshot available: just a half-transparent black overlay
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f * bgAlpha)))
        }

        // tap outside / swipe up to dismiss
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) { detectTapGestures { onRequestClose() } }
                .pointerInput(Unit) {
                    var acc = 0f
                    detectVerticalDragGestures(
                        onDragStart = { acc = 0f },
                        onDragEnd = { if (acc < -60f) onRequestClose() }
                    ) { ch, dy -> ch.consume(); acc += dy }
                }
        )

        StatusRow(c, p, statusDp, bgAlpha)

        Column(
            Modifier
                .align(if (wide) Alignment.TopEnd else Alignment.TopCenter)
                .width(panelW)
                .padding(top = statusDp + 6.dp, end = if (wide) 14.dp else 0.dp)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Header(c, p, Modifier.popIn(shown, 0))

            Row(Modifier.fillMaxWidth().height(138.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MediaCard(c, p, Modifier.weight(1f).fillMaxHeight().popIn(shown, 1))
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ConnTile(Icons.Rounded.Wifi, c.wifiOn, c.wifiName, p, c::toggleWifi, c::openWifi,
                        Modifier.weight(1f).fillMaxWidth().popIn(shown, 2))
                    ConnTile(Icons.Rounded.Bluetooth, c.btOn, "Bluetooth", p, c::toggleBt, c::openBt,
                        Modifier.weight(1f).fillMaxWidth().popIn(shown, 3))
                }
            }

            GlassCard(p, Modifier.fillMaxWidth().popIn(shown, 4)) {
                Column(Modifier.padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 2.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        c.mainTiles().forEach { t -> CircleToggle(t.icon, t.active, p, 46.dp, t.onClick, t.onLong) }
                    }
                    Spacer(Modifier.height(14.dp))
                    HmSlider(c.brightness, c::setBrightness, p, Icons.Rounded.BrightnessLow, Icons.Rounded.BrightnessHigh)
                    AnimatedVisibility(
                        expanded,
                        enter = expandVertically(spring(stiffness = Spring.StiffnessMediumLow)) + fadeIn(tween(200)),
                        exit = shrinkVertically(tween(220)) + fadeOut(tween(150))
                    ) {
                        Column {
                            Spacer(Modifier.height(16.dp))
                            c.extraTiles().chunked(4).forEachIndexed { row, tiles ->
                                Row(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                                    tiles.forEachIndexed { i, t ->
                                        Column(
                                            Modifier.weight(1f).popIn(expanded, row * 4 + i),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            CircleToggle(t.icon, t.active, p, 46.dp, t.onClick, t.onLong)
                                            Spacer(Modifier.height(4.dp))
                                            Text(t.label, fontSize = 10.sp, color = p.sub, maxLines = 1,
                                                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                                        }
                                    }
                                }
                            }
                            HmSlider(c.volMusic, { c.setVolume(AudioManager.STREAM_MUSIC, it) }, p, Icons.Rounded.MusicNote, Icons.Rounded.VolumeUp)
                            HmSlider(c.volRing, { c.setVolume(AudioManager.STREAM_RING, it) }, p, Icons.Rounded.NotificationsActive, Icons.Rounded.VolumeUp)
                            HmSlider(c.volAlarm, { c.setVolume(AudioManager.STREAM_ALARM, it) }, p, Icons.Rounded.Alarm, Icons.Rounded.VolumeUp)
                            HmSlider(if (c.eyeOn) c.eyeStrength else 0f, c::setEyeStrength, p, Icons.Rounded.RemoveRedEye, Icons.Rounded.WbSunny)
                        }
                    }
                    HandleBar(p, { expanded = false }, { expanded = true }, { expanded = !expanded })
                }
            }

            GlassCard(p, Modifier.fillMaxWidth().popIn(shown, 5)) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Super Device", fontSize = 12.sp, color = p.text, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                        IconTap(Icons.Rounded.TrackChanges, p.text.copy(alpha = 0.8f), c::openBt, 28.dp, 18.dp)
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        c.devices.forEach { d ->
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                CircleToggle(d.icon, d.active, p, 38.dp, d.onClick)
                                Spacer(Modifier.height(5.dp))
                                Text(d.name, fontSize = 10.sp, color = p.text.copy(alpha = 0.85f), maxLines = 1,
                                    overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }
            }

            GlassCard(p, Modifier.fillMaxWidth().popIn(shown, 6)) {
                Column(Modifier.padding(start = 8.dp, end = 8.dp, top = 8.dp)) {
                    val all = listOf(
                        "Home" to Icons.Rounded.MeetingRoom, "Happy Day" to Icons.Rounded.FreeBreakfast,
                        "Leave Home" to Icons.Rounded.DirectionsWalk, "Sleep" to Icons.Rounded.Bedtime,
                        "Movie" to Icons.Rounded.Movie, "Party" to Icons.Rounded.Celebration
                    )
                    val rows = if (scenesOpen) all.chunked(2) else all.take(2).chunked(2)
                    rows.forEach { pair ->
                        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { (name, icon) -> SceneButton(name, icon, name in c.scenes, p, Modifier.weight(1f)) { c.toggleScene(name) } }
                        }
                    }
                    HandleBar(p, { scenesOpen = false }, { scenesOpen = true }, { scenesOpen = !scenesOpen })
                }
            }

            Row(Modifier.fillMaxWidth().height(96.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DeviceCard("AI Full view Camera", if (c.camOn) "Online" else "Offline", c.camOn, true, p, c::toggleCam,
                    Modifier.weight(1f).fillMaxHeight().popIn(shown, 7))
                DeviceCard("Smart Air Purifier", if (c.purifierOn) "On" else "Off", c.purifierOn, false, p, c::togglePurifier,
                    Modifier.weight(1f).fillMaxHeight().popIn(shown, 8))
            }
        }
    }
}

@Composable
private fun StatusRow(c: SystemController, p: Palette, h: Dp, alpha: Float) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val fmt = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm"
    Row(
        Modifier.fillMaxWidth().height(h).padding(horizontal = 16.dp).graphicsLayer { this.alpha = alpha },
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End
    ) {
        if (c.wifiOn) Icon(Icons.Rounded.Wifi, null, tint = p.text, modifier = Modifier.size(13.dp))
        if (c.btOn) Icon(Icons.Rounded.Bluetooth, null, tint = p.text, modifier = Modifier.size(13.dp).padding(start = 3.dp))
        Spacer(Modifier.width(6.dp))
        Canvas(Modifier.size(20.dp, 10.dp)) {
            val stroke = 1.dp.toPx()
            drawRoundRect(p.text.copy(alpha = 0.55f), size = size, cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()),
                style = androidx.compose.ui.graphics.drawscope.Stroke(stroke))
            drawRoundRect(if (c.charging) Color(0xFF30D158) else p.text, Offset(2.dp.toPx(), 2.dp.toPx()),
                androidx.compose.ui.geometry.Size((size.width - 4.dp.toPx()) * c.battery / 100f, size.height - 4.dp.toPx()),
                androidx.compose.ui.geometry.CornerRadius(1.5.dp.toPx()))
        }
        Spacer(Modifier.width(4.dp))
        Text("${c.battery}%", fontSize = 11.sp, color = p.text)
        Spacer(Modifier.width(8.dp))
        Text(SimpleDateFormat(fmt, Locale.getDefault()).format(Date(now)), fontSize = 12.sp, color = p.text)
    }
}

@Composable
private fun Header(c: SystemController, p: Palette, modifier: Modifier) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val fmt = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm a"
    Row(modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(SimpleDateFormat(fmt, Locale.getDefault()).format(Date(now)), fontSize = 30.sp, fontWeight = FontWeight.Medium, color = p.text)
            Text(SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date(now)), fontSize = 12.sp, color = p.sub)
        }
        IconTap(Icons.Rounded.EditNote, p.text, c::openApp)
        IconTap(Icons.Rounded.Settings, p.text, c::openSystemSettings)
    }
}

@Composable
private fun MediaCard(c: SystemController, p: Palette, modifier: Modifier) {
    GlassCard(p, modifier) {
        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Box(Modifier.size(46.dp)) {
                    val art = c.mediaArt
                    if (c.mediaReal && art != null) {
                        Image(art.asImageBitmap(), null, Modifier.fillMaxSize().clip(RoundedCornerShape(9.dp)), contentScale = ContentScale.Crop)
                    } else {
                        Box(
                            Modifier.fillMaxSize().clip(RoundedCornerShape(9.dp)).background(
                                Brush.linearGradient(listOf(Color(0xFF7A1E1E), Color(0xFF1B1B2F), Color(0xFFD64545)))
                            ), contentAlignment = Alignment.Center
                        ) { Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(22.dp)) }
                    }
                    Box(
                        Modifier.align(Alignment.BottomEnd).offset(4.dp, 4.dp).size(16.dp).clip(CircleShape).background(p.accent),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Rounded.MusicNote, null, tint = Color.White, modifier = Modifier.size(10.dp)) }
                }
                Spacer(Modifier.weight(1f))
                IconTap(Icons.Rounded.Cast, p.text.copy(alpha = 0.8f), c::openCast, 30.dp, 17.dp)
            }
            Column {
                Text(if (c.mediaReal) c.mediaTitle ?: "" else "Dream It Possible", fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (c.mediaReal) c.mediaArtist ?: "" else "Delacey", fontSize = 11.sp, color = p.sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconTap(Icons.Rounded.SkipPrevious, p.text, c::prevTrack, 36.dp, 22.dp)
                IconTap(if (c.isPlayingUi) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, p.text, c::playPause, 36.dp, 24.dp)
                IconTap(Icons.Rounded.SkipNext, p.text, c::nextTrack, 36.dp, 22.dp)
            }
        }
    }
}

@Composable
private fun ConnTile(
    icon: ImageVector, active: Boolean, title: String, p: Palette,
    onToggle: () -> Unit, onOpen: () -> Unit, modifier: Modifier
) {
    GlassCard(p, modifier, 20.dp, onClick = onOpen) {
        Row(Modifier.fillMaxSize().padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            CircleToggle(icon, active, p, 38.dp, onToggle)
            Spacer(Modifier.width(9.dp))
            Text(title, fontSize = 12.sp, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        }
        Canvas(Modifier.align(Alignment.BottomEnd).padding(6.dp).size(6.dp)) {
            val path = Path().apply { moveTo(size.width, 0f); lineTo(size.width, size.height); lineTo(0f, size.height); close() }
            drawPath(path, p.text.copy(alpha = 0.55f))
        }
    }
}

@Composable
private fun SceneButton(name: String, icon: ImageVector, active: Boolean, p: Palette, modifier: Modifier, onClick: () -> Unit) {
    val bg by androidx.compose.animation.animateColorAsState(if (active) p.accent.copy(alpha = 0.9f) else p.tileOff.copy(alpha = if (p.dark) 0.18f else 0.08f), tween(240), label = "sc")
    Row(
        modifier.height(42.dp).pressScale(onClick, null, 0.95f).clip(RoundedCornerShape(14.dp)).background(bg).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (active) Color.White else p.text.copy(alpha = 0.85f), modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(name, fontSize = 12.sp, color = if (active) Color.White else p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun DeviceCard(title: String, status: String, on: Boolean, camera: Boolean, p: Palette, onPower: () -> Unit, modifier: Modifier) {
    GlassCard(p, modifier) {
        Column(Modifier.padding(start = 12.dp, top = 10.dp, end = 8.dp)) {
            Text(title, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("$status | Living room", fontSize = 9.sp, color = p.sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        // little product drawing
        Canvas(Modifier.align(Alignment.BottomStart).padding(start = 22.dp, bottom = 8.dp).size(24.dp, 34.dp)) {
            val body = Color.White.copy(alpha = if (p.dark) 0.9f else 0.95f)
            if (camera) {
                drawRoundRect(body, Offset(size.width * 0.15f, size.height * 0.1f), androidx.compose.ui.geometry.Size(size.width * 0.7f, size.height * 0.9f),
                    androidx.compose.ui.geometry.CornerRadius(size.width * 0.3f))
                drawCircle(Color(0xFF2B2F36), size.width * 0.17f, Offset(size.width / 2, size.height * 0.4f))
            } else {
                drawRoundRect(body, Offset(0f, size.height * 0.05f), androidx.compose.ui.geometry.Size(size.width, size.height * 0.95f),
                    androidx.compose.ui.geometry.CornerRadius(size.width * 0.3f))
                drawCircle(Color(0xFFB8BEC8), size.width * 0.28f, Offset(size.width / 2, size.height * 0.3f))
            }
        }
        val bg by androidx.compose.animation.animateColorAsState(if (on) p.accent else p.tileOff, tween(240), label = "pw")
        Box(
            Modifier.align(Alignment.BottomEnd).padding(8.dp).size(28.dp).pressScale(onPower, null, 0.85f).clip(CircleShape).background(bg),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.PowerSettingsNew, null, tint = if (on) Color.White else p.iconOff, modifier = Modifier.size(15.dp)) }
    }
}
