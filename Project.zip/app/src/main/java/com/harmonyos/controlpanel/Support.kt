package com.harmonyos.controlpanel

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner

object Prefs {
    const val NAME = "hmos_cp"
    fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun bool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun float(c: Context, k: String, d: Float) = sp(c).getFloat(k, d)
    fun setFloat(c: Context, k: String, v: Float) = sp(c).edit().putFloat(k, v).apply()
    fun int(c: Context, k: String, d: Int): Int = try { sp(c).getInt(k, d) } catch (_: Throwable) { d }
    fun setInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun str(c: Context, k: String, d: String?): String? = try { sp(c).getString(k, d) } catch (_: Throwable) { d }
    fun setStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
}

object Haptics {
    @Volatile
    var enabled = true
}

/** Downscale + box blur. Cheap, works on every API level, looks like HarmonyOS' frosted backdrop. */
object BlurUtil {
    fun blur(src: Bitmap, scale: Int = 10, radius: Int = 4, passes: Int = 3): Bitmap {
        val w = maxOf(1, src.width / scale)
        val h = maxOf(1, src.height / scale)
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        var a = IntArray(w * h)
        var b = IntArray(w * h)
        small.getPixels(a, 0, w, 0, 0, w, h)
        repeat(passes) {
            pass(a, b, w, h, radius, true)
            pass(b, a, w, h, radius, false)
        }
        small.setPixels(a, 0, w, 0, 0, w, h)
        if (small !== src) src.recycle()
        return small
    }

    private fun pass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val n = 2 * r + 1
        for (y in 0 until h) for (x in 0 until w) {
            var a = 0; var rr = 0; var g = 0; var b = 0
            for (k in -r..r) {
                val xx = if (horizontal) (x + k).coerceIn(0, w - 1) else x
                val yy = if (horizontal) y else (y + k).coerceIn(0, h - 1)
                val p = src[yy * w + xx]
                a += p ushr 24
                rr += (p shr 16) and 255
                g += (p shr 8) and 255
                b += p and 255
            }
            dst[y * w + x] = ((a / n) shl 24) or ((rr / n) shl 16) or ((g / n) shl 8) or (b / n)
        }
    }
}

/** Transparent strip at the top edge. Touch-down pre-captures the screen; a short pull opens the panel. */
class EdgeView(ctx: Context, private val onDown: () -> Unit, private val onPull: () -> Unit) : View(ctx) {
    private var startY = 0f
    private var fired = false
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { startY = e.rawY; fired = false; onDown() }
            MotionEvent.ACTION_MOVE ->
                if (!fired && e.rawY - startY > 12 * resources.displayMetrics.density) {
                    fired = true
                    if (Haptics.enabled) performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                    onPull()
                }
        }
        return true
    }
}

/** Gives a ComposeView hosted in a Service window the lifecycle owners it needs. */
class OverlayOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val reg = LifecycleRegistry(this)
    private val ssc = SavedStateRegistryController.create(this)
    private val vms = ViewModelStore()

    override val lifecycle: Lifecycle get() = reg
    override val savedStateRegistry: SavedStateRegistry get() = ssc.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = vms

    init {
        ssc.performAttach()
        ssc.performRestore(null)
    }

    fun resume() { reg.currentState = Lifecycle.State.RESUMED }
    fun destroy() { reg.currentState = Lifecycle.State.DESTROYED; vms.clear() }
}

/** Root of the overlay window; forwards BACK so the panel closes with an animation. */
class PanelLayout(ctx: Context, private val onBack: () -> Unit) : FrameLayout(ctx) {
    init { isFocusable = true; isFocusableInTouchMode = true }
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) onBack()
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}
