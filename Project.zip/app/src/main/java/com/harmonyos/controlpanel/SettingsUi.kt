package com.harmonyos.controlpanel

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val Ink = Color(0xFF111111)
private val Muted = Color(0x99000000)

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        content()
    }
}

@Composable
fun PBool(label: String, key: String, def: Boolean, desc: String? = null) {
    val ctx = LocalContext.current
    var v by remember { mutableStateOf(Prefs.bool(ctx, key, def)) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Text(label, fontSize = 13.sp, color = Ink)
            if (desc != null) Text(desc, fontSize = 11.sp, color = Muted)
        }
        Switch(v, { v = it; Prefs.setBool(ctx, key, it) }, colors = SwitchDefaults.colors(checkedTrackColor = HmBlue))
    }
}

@Composable
fun PSlider(label: String, key: String, def: Int, min: Int, max: Int, unit: String = "", onDone: (Int) -> Unit = {}) {
    val ctx = LocalContext.current
    var v by remember { mutableIntStateOf(Prefs.int(ctx, key, def)) }
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, fontSize = 13.sp, color = Ink, modifier = Modifier.weight(1f))
            Text("$v$unit", fontSize = 12.sp, color = Muted)
        }
        Slider(
            value = v.toFloat(),
            onValueChange = { v = it.roundToInt() },
            onValueChangeFinished = { Prefs.setInt(ctx, key, v); onDone(v) },
            valueRange = min.toFloat()..max.toFloat(),
            colors = SliderDefaults.colors(thumbColor = HmBlue, activeTrackColor = HmBlue)
        )
    }
}

@Composable
fun Chip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(16.dp))
            .background(if (selected) HmBlue else Color(0x12000000))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 12.sp, color = if (selected) Color.White else Ink, maxLines = 1,
            overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

@Composable
fun PChoice(label: String, key: String, def: String, options: List<String>, onPick: (String) -> Unit = {}) {
    val ctx = LocalContext.current
    var v by remember { mutableStateOf(Prefs.str(ctx, key, def) ?: def) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, fontSize = 13.sp, color = Ink)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { o -> Chip(o, o == v) { v = o; Prefs.setStr(ctx, key, o); onPick(o) } }
        }
    }
}

// ------------------------------------------------------------------ animations

@Composable
private fun MiniCard(modifier: Modifier, content: @Composable () -> Unit = {}) {
    Box(modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.7f)), contentAlignment = Alignment.Center) { content() }
}

@Composable
fun AnimPreview(preset: String, speedPct: Int, enabled: Boolean, replay: Int) {
    key(replay, preset, speedPct, enabled) {
        CompositionLocalProvider(LocalAnim provides AnimConfig(enabled, preset, speedPct / 100f, true, true)) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF7FB9C4), Color(0xFF8FA9D8))))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(Modifier.fillMaxWidth().height(84.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MiniCard(Modifier.weight(1f).fillMaxHeight().popIn(true, 0)) {
                        Icon(Icons.Rounded.MusicNote, null, tint = HmBlue, modifier = Modifier.size(26.dp))
                    }
                    Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        MiniCard(Modifier.weight(1f).fillMaxWidth().popIn(true, 1))
                        MiniCard(Modifier.weight(1f).fillMaxWidth().popIn(true, 2))
                    }
                }
                MiniCard(Modifier.fillMaxWidth().height(60.dp).popIn(true, 3)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        repeat(5) { i -> Box(Modifier.size(28.dp).clip(CircleShape).background(if (i == 1) HmBlue else Color(0x22000000))) }
                    }
                }
                Row(Modifier.fillMaxWidth().height(40.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MiniCard(Modifier.weight(1f).fillMaxHeight().popIn(true, 4))
                    MiniCard(Modifier.weight(1f).fillMaxHeight().popIn(true, 5))
                }
            }
        }
    }
}

@Composable
fun AnimationSettings() {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(Prefs.bool(ctx, "anim_on", true)) }
    var preset by remember { mutableStateOf(Prefs.str(ctx, "anim_preset", "HarmonyOS") ?: "HarmonyOS") }
    var speed by remember { mutableIntStateOf(Prefs.int(ctx, "anim_speed", 100)) }
    var replay by remember { mutableIntStateOf(0) }
    SectionCard("Animations") {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Enable animations", fontSize = 13.sp, color = Ink)
                Text("Off = the panel appears instantly", fontSize = 11.sp, color = Muted)
            }
            Switch(on, { on = it; Prefs.setBool(ctx, "anim_on", it) }, colors = SwitchDefaults.colors(checkedTrackColor = HmBlue))
        }
        AnimPreview(preset, speed, on, replay)
        Text("Presets - tap one to select and preview it", fontSize = 13.sp, color = Ink)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AnimPresets.all.forEach { a ->
                Chip(a.name, a.name == preset) {
                    preset = a.name; Prefs.setStr(ctx, "anim_preset", a.name); replay++
                }
            }
        }
        Text(AnimPresets.get(preset).desc, fontSize = 11.sp, color = Muted)
        PSlider("Animation speed", "anim_speed", 100, 50, 250, "%") { speed = it }
        Button(
            onClick = { replay++ }, shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = HmBlue)
        ) { Text("Replay preview") }
        PBool("Press feedback", "anim_press", true, "Cards and buttons shrink slightly when pressed")
        PBool("Toggle bounce", "anim_toggle", true, "Circles bounce when switched on or off")
    }
}

// ------------------------------------------------------------------ layout

@Composable
private fun SectionOrderEditor() {
    val ctx = LocalContext.current
    var order by remember { mutableStateOf(loadSectionOrder(ctx)) }
    var hidden by remember {
        mutableStateOf((Prefs.str(ctx, "ly_hide", "") ?: "").split(",").filter { it.isNotBlank() }.toSet())
    }
    fun save() {
        Prefs.setStr(ctx, "ly_order", order.joinToString(","))
        Prefs.setStr(ctx, "ly_hide", hidden.joinToString(","))
    }
    fun move(i: Int, d: Int) {
        val j = i + d
        if (j < 0 || j >= order.size) return
        val l = order.toMutableList()
        val t = l[i]; l[i] = l[j]; l[j] = t
        order = l; save()
    }
    Text("Sections - show / hide and reorder", fontSize = 13.sp, color = Ink)
    order.forEachIndexed { i, id ->
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Switch(
                id !in hidden,
                { on -> hidden = if (on) hidden - id else hidden + id; save() },
                colors = SwitchDefaults.colors(checkedTrackColor = HmBlue)
            )
            Text(SECTION_LABELS[id] ?: id, fontSize = 12.sp, color = Ink, modifier = Modifier.weight(1f).padding(start = 10.dp))
            TextButton(onClick = { move(i, -1) }) { Text("Up", color = HmBlue) }
            TextButton(onClick = { move(i, 1) }) { Text("Down", color = HmBlue) }
        }
    }
}

@Composable
private fun QuickTilesEditor() {
    val ctx = LocalContext.current
    var quick by remember { mutableStateOf(loadQuick(ctx)) }
    Text("Quick row toggles (${quick.size}/7, min 3) - everything else goes in the expanded area", fontSize = 13.sp, color = Ink)
    TILE_LABELS.entries.toList().chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            row.forEach { (id, label) ->
                Chip(label, id in quick, Modifier.weight(1f)) {
                    quick = if (id in quick) { if (quick.size > 3) quick - id else quick }
                    else { if (quick.size < 7) quick + id else quick }
                    Prefs.setStr(ctx, "ly_quick", quick.joinToString(","))
                }
            }
            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

@Composable
fun LayoutSettings() {
    SectionCard("Layout & look") {
        SectionOrderEditor()
        QuickTilesEditor()
        PChoice("Panel position", "ly_pos", "Right", listOf("Right", "Left", "Center"))
        PSlider("Panel width", "ly_width", 380, 280, 460, " dp")
        PSlider("Card corner radius", "ly_radius", 22, 6, 34, " dp")
        PSlider("Card opacity", "ly_alpha", 64, 15, 100, "%")
        PBool("Card outline", "ly_outline", false, "Thin light border around every card (off by default)")
        PSlider("Space between cards", "ly_spacing", 8, 2, 18, " dp")
        PSlider("Quick toggle size", "ly_tile", 46, 34, 56, " dp")
        PChoice("Backdrop", "backdrop", "Blur", listOf("Blur", "Dim"))
        Text("Blur = blurred screenshot of what's behind (a moment slower). Dim = instant dark overlay, no screenshot.", fontSize = 11.sp, color = Muted)
        PChoice("Blur strength", "blur", "Medium", listOf("Light", "Medium", "Strong"))
        PSlider("Wash over the blur", "ly_dim", 22, 0, 60, "%")
        PSlider("Dim amount when there is no blur", "ly_fallback_dim", 50, 0, 90, "%")
        PBool("Status row (battery, time) at the top", "ly_status", true)
        PBool("Date under the clock", "ly_date", true)
        PChoice("Clock format", "ly_timefmt", "System", listOf("System", "12-hour", "24-hour"))
        PBool("Brightness slider", "ly_bright", true)
        PBool("Volume sliders (expanded area)", "ly_vol", true)
        PBool("Eye comfort slider (expanded area)", "ly_eye", true)
        PBool("Open with the toggles area already expanded", "ly_expanded", false)
    }
}

// ------------------------------------------------------------------ media

@Composable
fun MediaSettings() {
    SectionCard("Media player") {
        PBool("Show media card", "md_show", true)
        PChoice("Style", "md_style", "Standard", listOf("Standard", "Large art", "Minimal"))
        PChoice("Artwork shape", "md_shape", "Rounded", listOf("Rounded", "Circle", "Square"))
        PSlider("Artwork size", "md_artsize", 46, 30, 72, " dp")
        PSlider("Card height", "md_height", 138, 100, 190, " dp")
        PBool("Show artwork (Standard style)", "md_art", true)
        PBool("App badge on artwork", "md_badge", true)
        PBool("Cast button", "md_cast", true)
        PBool("Demo track when nothing is playing", "md_demo", true, "Off = shows \"Nothing playing\"")
        PBool("Hide the card when nothing is playing", "md_hide", false, "Needs notification access to detect playback")
    }
}
