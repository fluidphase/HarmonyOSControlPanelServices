package com.harmonyos.controlpanel

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.annotation.RequiresApi
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.unit.dp
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner

/**
 * The heart of the app. As an accessibility service it can:
 *  - take a screenshot of whatever is on screen (API 30+) -> blur -> use as the panel backdrop
 *  - add overlay windows above every app (panel, edge pull-zone, eye-comfort tint)
 *  - run global actions (lock, screenshot, power menu)
 */
class ControlPanelService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ControlPanelService? = null
    }

    private lateinit var wm: WindowManager
    lateinit var controller: SystemController
    private val handler = Handler(Looper.getMainLooper())

    private var panel: PanelLayout? = null
    private var owner: OverlayOwner? = null
    private var edge: View? = null
    private var eye: View? = null
    private var busy = false
    private var lastEdgeWidth = -1
    private val closeSignal = mutableIntStateOf(0)

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> handler.post { applyPrefs() } }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        controller = SystemController(this, this)
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                accessibilityButtonController.registerAccessibilityButtonCallback(
                    object : AccessibilityButtonController.AccessibilityButtonCallback() {
                        override fun onClicked(controller: AccessibilityButtonController) { showPanel() }
                    })
            } catch (_: Throwable) {}
        }
        applyPrefs()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        removeEdge(); applyPrefs()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        teardown(); return super.onUnbind(intent)
    }

    override fun onDestroy() { teardown(); super.onDestroy() }

    private fun teardown() {
        instance = null
        try { Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener) } catch (_: Throwable) {}
        removeEdge(); removeEye(); removePanel()
        if (::controller.isInitialized) controller.release()
    }

    // ---------- prefs ----------
    private fun applyPrefs() {
        Haptics.enabled = Prefs.bool(this, "haptics", true)
        if (Prefs.bool(this, "edge", true)) addEdge() else removeEdge()
        applyEye()
    }

    // ---------- edge pull zone ----------
    private fun addEdge() {
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.45f).toInt()
        if (edge != null && w == lastEdgeWidth) return
        removeEdge()
        lastEdgeWidth = w
        val v = EdgeView(this) { showPanel() }
        val lp = WindowManager.LayoutParams(
            w, (20 * dm.density).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END }
        try { wm.addView(v, lp); edge = v } catch (_: Throwable) {}
    }

    private fun removeEdge() {
        edge?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        edge = null; lastEdgeWidth = -1
    }

    // ---------- eye comfort tint ----------
    fun applyEye() {
        val on = Prefs.bool(this, "eye_on", false)
        val s = Prefs.float(this, "eye_strength", 0.5f)
        if (!on || s <= 0.02f) { removeEye(); return }
        val color = Color.argb((s * 105).toInt().coerceIn(0, 110), 255, 140, 30)
        val v = eye ?: View(this).also {
            val lp = WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            try { wm.addView(it, lp); eye = it } catch (_: Throwable) {}
        }
        v.setBackgroundColor(color)
    }

    private fun removeEye() {
        eye?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        eye = null
    }

    // ---------- panel ----------
    fun showFromTile() {
        if (Build.VERSION.SDK_INT >= 31) performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        handler.postDelayed({ showPanel() }, 550)
    }

    fun showPanel() {
        if (panel != null || busy) return
        busy = true
        if (Build.VERSION.SDK_INT >= 30 && Prefs.bool(this, "use_screenshot", true)) capture() else attach(null)
    }

    @RequiresApi(30)
    private fun capture() {
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    val hb = result.hardwareBuffer
                    val cs = result.colorSpace
                    Thread {
                        val blurred = try {
                            val hw = Bitmap.wrapHardwareBuffer(hb, cs)
                            val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            hw?.recycle()
                            soft?.let { BlurUtil.blur(it) }
                        } catch (_: Throwable) { null } finally { try { hb.close() } catch (_: Throwable) {} }
                        handler.post { attach(blurred) }
                    }.start()
                }

                override fun onFailure(errorCode: Int) { attach(null) }
            })
        } catch (_: Throwable) { attach(null) }
    }

    private var bgBitmap: Bitmap? = null

    private fun attach(bg: Bitmap?) {
        busy = false
        if (panel != null) return
        bgBitmap = bg
        controller.refresh()
        val o = OverlayOwner()
        val layout = PanelLayout(this) { hidePanel() }
        layout.setViewTreeLifecycleOwner(o)
        layout.setViewTreeSavedStateRegistryOwner(o)
        layout.setViewTreeViewModelStoreOwner(o)

        val resId = resources.getIdentifier("status_bar_height", "dimen", "android")
        val statusDp = (if (resId > 0) resources.getDimensionPixelSize(resId) else (24 * resources.displayMetrics.density).toInt()) /
            resources.displayMetrics.density

        val cv = ComposeView(this)
        cv.setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
        cv.setContent {
            PanelRoot(
                c = controller,
                bg = bgBitmap?.asImageBitmap(),
                statusDp = statusDp.dp,
                closeSignal = closeSignal.intValue,
                onRequestClose = { hidePanel() },
                onClosed = { removePanel() }
            )
        }
        layout.addView(cv, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        lp.title = "HarmonyOS Control Panel"

        closeSignal.intValue = 0
        o.resume()
        try {
            wm.addView(layout, lp)
            panel = layout; owner = o
            layout.requestFocus()
        } catch (_: Throwable) { o.destroy() }
    }

    fun hidePanel() {
        if (panel != null) closeSignal.intValue = closeSignal.intValue + 1
    }

    private fun removePanel() {
        panel?.let {
            (it.getChildAt(0) as? ComposeView)?.disposeComposition()
            try { wm.removeView(it) } catch (_: Throwable) {}
        }
        panel = null
        owner?.destroy(); owner = null
        bgBitmap = null
        closeSignal.intValue = 0
    }
}
