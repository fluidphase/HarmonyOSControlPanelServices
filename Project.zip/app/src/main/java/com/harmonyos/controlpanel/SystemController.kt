package com.harmonyos.controlpanel

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSessionManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.nfc.NfcAdapter
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Toast
import android.app.NotificationManager
import android.location.LocationManager
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.location.LocationManagerCompat
import kotlin.math.roundToInt

data class TileModel(
    val id: String,
    val label: String,
    val icon: ImageVector,
    val active: Boolean,
    val onClick: () -> Unit,
    val onLong: (() -> Unit)? = null
)

data class DeviceInfo(
    val id: String,
    val name: String,
    val icon: ImageVector,
    val active: Boolean,
    val onClick: () -> Unit
)

/**
 * Reads and writes the real system state. Everything is Compose state so the panel updates live.
 * Anything Android won't let a normal app change silently falls back to the matching system panel/screen.
 */
class SystemController(private val ctx: Context, private val service: ControlPanelService?) {

    private val handler = Handler(Looper.getMainLooper())
    private val cr = ctx.contentResolver
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val wifiMgr = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val btAdapter: BluetoothAdapter? =
        try { (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter } catch (e: Throwable) { null }
    private val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val camMgr = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager

    // ---- state ----
    var wifiOn by mutableStateOf(false)
    var wifiName by mutableStateOf("Wi-Fi")
    var btOn by mutableStateOf(false)
    var torch by mutableStateOf(false)
    var ringer by mutableIntStateOf(AudioManager.RINGER_MODE_NORMAL)
    var autoRotate by mutableStateOf(true)
    var airplane by mutableStateOf(false)
    var hotspot by mutableStateOf(false)
    var location by mutableStateOf(false)
    var brightness by mutableFloatStateOf(0.5f)
    var autoBright by mutableStateOf(false)
    var dnd by mutableStateOf(false)
    var nfc by mutableStateOf(false)
    var dark by mutableStateOf(false)
    var dataOn by mutableStateOf(false)
    var saver by mutableStateOf(false)
    var timeoutMs by mutableIntStateOf(30000)
    var volMusic by mutableFloatStateOf(0.5f)
    var volRing by mutableFloatStateOf(0.5f)
    var volAlarm by mutableFloatStateOf(0.5f)
    var battery by mutableIntStateOf(100)
    var charging by mutableStateOf(false)
    var eyeOn by mutableStateOf(Prefs.bool(ctx, "eye_on", false))
    var eyeStrength by mutableFloatStateOf(Prefs.float(ctx, "eye_strength", 0.5f))

    var mediaReal by mutableStateOf(false)
    var mediaTitle by mutableStateOf<String?>(null)
    var mediaArtist by mutableStateOf<String?>(null)
    var mediaArt by mutableStateOf<Bitmap?>(null)
    var mediaPlaying by mutableStateOf(false)
    var demoPlaying by mutableStateOf(true)

    var devices by mutableStateOf<List<DeviceInfo>>(emptyList())
    private var demoActive by mutableStateOf(setOf("buds"))

    var camOn by mutableStateOf(Prefs.bool(ctx, "cam_on", true))
    var purifierOn by mutableStateOf(Prefs.bool(ctx, "purifier_on", false))
    var scenes by mutableStateOf(Prefs.sp(ctx).getStringSet("scenes", emptySet())!!.toSet())

    private var lastNag = 0L
    private var torchId: String? = null
    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchId) torch = enabled
        }
    }

    init {
        try {
            torchId = camMgr.cameraIdList.firstOrNull {
                val ch = camMgr.getCameraCharacteristics(it)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
            camMgr.registerTorchCallback(torchCb, handler)
        } catch (_: Throwable) {}
    }

    fun release() {
        try { camMgr.unregisterTorchCallback(torchCb) } catch (_: Throwable) {}
    }

    // ---- helpers ----
    private fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()
    private fun hasSecure() = ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED
    private fun hasBtPerm() = Build.VERSION.SDK_INT < 31 ||
        ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    private fun sysInt(k: String, d: Int) = try { Settings.System.getInt(cr, k, d) } catch (_: Throwable) { d }

    fun launch(i: Intent) {
        try {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
        }
        service?.hidePanel()
    }

    private fun putSys(k: String, v: Int): Boolean {
        if (!Settings.System.canWrite(ctx)) {
            val now = SystemClock.uptimeMillis()
            if (now - lastNag > 2500) {
                lastNag = now
                toast("Allow \"Modify system settings\" for HarmonyOS Control Panel")
                launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            }
            return false
        }
        return try { Settings.System.putInt(cr, k, v) } catch (_: Throwable) { false }
    }

    private fun closeThen(delayMs: Long, block: () -> Unit) {
        service?.hidePanel()
        handler.postDelayed(block, delayMs)
    }

    // ---- refresh ----
    @Suppress("DEPRECATION")
    fun refresh() {
        wifiOn = try { wifiMgr.isWifiEnabled } catch (_: Throwable) { false }
        wifiName = if (!wifiOn) "Wi-Fi" else try {
            val s = wifiMgr.connectionInfo?.ssid?.trim('"')
            if (s.isNullOrBlank() || s.contains("unknown ssid")) "Wi-Fi" else s
        } catch (_: Throwable) { "Wi-Fi" }
        btOn = try { btAdapter?.isEnabled == true } catch (_: Throwable) { false }
        ringer = audio.ringerMode
        autoRotate = sysInt(Settings.System.ACCELEROMETER_ROTATION, 1) == 1
        airplane = try { Settings.Global.getInt(cr, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (_: Throwable) { false }
        location = try { LocationManagerCompat.isLocationEnabled(lm) } catch (_: Throwable) { false }
        brightness = (sysInt(Settings.System.SCREEN_BRIGHTNESS, 128) / 255f).coerceIn(0f, 1f)
        autoBright = sysInt(Settings.System.SCREEN_BRIGHTNESS_MODE, 0) == 1
        timeoutMs = sysInt(Settings.System.SCREEN_OFF_TIMEOUT, 30000)
        dnd = nm.currentInterruptionFilter in 2..4
        nfc = try { NfcAdapter.getDefaultAdapter(ctx)?.isEnabled == true } catch (_: Throwable) { false }
        dark = (ctx.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        dataOn = try {
            cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        } catch (_: Throwable) { false }
        saver = pm.isPowerSaveMode
        volMusic = vol(AudioManager.STREAM_MUSIC)
        volRing = vol(AudioManager.STREAM_RING)
        volAlarm = vol(AudioManager.STREAM_ALARM)
        hotspot = try {
            val m = WifiManager::class.java.getDeclaredMethod("isWifiApEnabled"); m.isAccessible = true
            m.invoke(wifiMgr) as Boolean
        } catch (_: Throwable) { false }
        try {
            val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (b != null) {
                val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (lvl >= 0) battery = lvl * 100 / sc
                val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            }
        } catch (_: Throwable) {}
        refreshMedia()
        devices = buildDevices()
    }

    private fun vol(stream: Int): Float {
        val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
        return audio.getStreamVolume(stream).toFloat() / max
    }

    private fun refreshMedia() {
        mediaPlaying = audio.isMusicActive
        try {
            val s = msm.getActiveSessions(ComponentName(ctx, MediaListenerService::class.java)).firstOrNull()
            if (s != null) {
                val md = s.metadata
                mediaTitle = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
                mediaArtist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                mediaArt = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                mediaReal = mediaTitle != null
            } else mediaReal = false
        } catch (_: Throwable) { mediaReal = false }
    }

    // ---- toggles ----
    fun toggleTorch() {
        val id = torchId ?: return toast("No flashlight on this device")
        try { camMgr.setTorchMode(id, !torch) } catch (_: Throwable) { toast("Flashlight unavailable") }
    }

    fun cycleRinger() {
        val next = when (audio.ringerMode) {
            AudioManager.RINGER_MODE_NORMAL -> AudioManager.RINGER_MODE_VIBRATE
            AudioManager.RINGER_MODE_VIBRATE -> AudioManager.RINGER_MODE_SILENT
            else -> AudioManager.RINGER_MODE_NORMAL
        }
        try {
            audio.ringerMode = next
        } catch (_: SecurityException) {
            if (!nm.isNotificationPolicyAccessGranted) {
                toast("Grant Do Not Disturb access to use silent mode")
                launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        }
        ringer = audio.ringerMode
    }

    fun toggleRotation() { if (putSys(Settings.System.ACCELEROMETER_ROTATION, if (autoRotate) 0 else 1)) autoRotate = !autoRotate }

    @Suppress("DEPRECATION")
    fun toggleWifi() {
        if (Build.VERSION.SDK_INT < 29) { wifiMgr.isWifiEnabled = !wifiOn; wifiOn = !wifiOn } else openWifi()
    }

    fun openWifi() = launch(Intent(
        if (Build.VERSION.SDK_INT >= 30) Settings.Panel.ACTION_WIFI
        else if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY
        else Settings.ACTION_WIFI_SETTINGS))

    @Suppress("DEPRECATION")
    fun toggleBt() {
        val a = btAdapter ?: return toast("Bluetooth unavailable")
        if (Build.VERSION.SDK_INT < 33) {
            try { if (a.isEnabled) a.disable() else a.enable(); btOn = !btOn; return } catch (_: SecurityException) {}
        }
        openBt()
    }

    fun openBt() = launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))

    fun openHotspot() {
        try {
            ctx.startActivity(Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            service?.hidePanel()
        } catch (_: Throwable) { launch(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
    }

    @Suppress("DEPRECATION")
    fun toggleLocation() {
        if (hasSecure()) {
            try { Settings.Secure.putInt(cr, Settings.Secure.LOCATION_MODE, if (location) 0 else 3); location = !location; return } catch (_: Throwable) {}
        }
        launch(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
    }

    fun toggleAirplane() {
        if (hasSecure()) {
            try {
                val on = !airplane
                Settings.Global.putInt(cr, Settings.Global.AIRPLANE_MODE_ON, if (on) 1 else 0)
                try { ctx.sendBroadcast(Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED).putExtra("state", on)) } catch (_: Throwable) {}
                airplane = on; return
            } catch (_: Throwable) {}
        }
        launch(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
    }

    fun setBrightness(f: Float) {
        brightness = f
        if (putSys(Settings.System.SCREEN_BRIGHTNESS_MODE, 0)) {
            putSys(Settings.System.SCREEN_BRIGHTNESS, (f * 255).roundToInt().coerceIn(1, 255))
            autoBright = false
        }
    }

    fun toggleAutoBright() { if (putSys(Settings.System.SCREEN_BRIGHTNESS_MODE, if (autoBright) 0 else 1)) autoBright = !autoBright }

    fun toggleDnd() {
        if (!nm.isNotificationPolicyAccessGranted) {
            toast("Grant Do Not Disturb access")
            launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); return
        }
        setDnd(!dnd)
    }

    private fun setDnd(on: Boolean) {
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
            dnd = on
        }
    }

    fun openNfc() = launch(Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_NFC else Settings.ACTION_NFC_SETTINGS))

    fun toggleDark() {
        if (hasSecure()) {
            try { Settings.Secure.putInt(cr, "ui_night_mode", if (dark) 1 else 2); dark = !dark; return } catch (_: Throwable) {}
        }
        launch(Intent(Settings.ACTION_DISPLAY_SETTINGS))
    }

    fun openData() = launch(Intent(
        if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_DATA_ROAMING_SETTINGS))

    fun toggleSaver() {
        if (hasSecure()) {
            try { Settings.Global.putInt(cr, "low_power", if (saver) 0 else 1); saver = !saver; return } catch (_: Throwable) {}
        }
        launch(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
    }

    fun setEye(on: Boolean, s: Float) {
        eyeOn = on; eyeStrength = s
        Prefs.setBool(ctx, "eye_on", on); Prefs.setFloat(ctx, "eye_strength", s)
        service?.applyEye()
    }

    fun toggleEye() = setEye(!eyeOn, if (eyeStrength < 0.1f) 0.5f else eyeStrength)
    fun setEyeStrength(s: Float) = setEye(s > 0.02f, s)

    private val timeouts = listOf(15000, 30000, 60000, 120000, 300000, 600000, 1800000)
    fun cycleTimeout() {
        val i = timeouts.indexOf(timeoutMs)
        val next = timeouts[if (i < 0) 0 else (i + 1) % timeouts.size]
        if (putSys(Settings.System.SCREEN_OFF_TIMEOUT, next)) timeoutMs = next
    }
    fun timeoutLabel() = if (timeoutMs < 60000) "${timeoutMs / 1000}s" else "${timeoutMs / 60000}m"

    fun setVolume(stream: Int, f: Float) {
        val max = audio.getStreamMaxVolume(stream)
        try { audio.setStreamVolume(stream, (f * max).roundToInt(), 0) } catch (_: SecurityException) {}
        when (stream) {
            AudioManager.STREAM_MUSIC -> volMusic = f
            AudioManager.STREAM_RING -> volRing = f
            else -> volAlarm = f
        }
    }

    // ---- global actions via accessibility ----
    fun lockScreen() = closeThen(250) { if (Build.VERSION.SDK_INT >= 28) service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) }
    fun screenshot() = closeThen(550) { if (Build.VERSION.SDK_INT >= 28) service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) }
    fun powerMenu() = closeThen(250) { service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG) }
    fun openSystemSettings() = launch(Intent(Settings.ACTION_SETTINGS))
    fun openApp() = launch(Intent(ctx, MainActivity::class.java))
    fun openCamera() = launch(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
    fun openCast() = launch(Intent(Settings.ACTION_CAST_SETTINGS))

    // ---- media ----
    private fun mediaKey(code: Int) {
        val t = SystemClock.uptimeMillis()
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    }
    val isPlayingUi get() = if (mediaReal) mediaPlaying else demoPlaying
    fun playPause() { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); if (mediaReal) mediaPlaying = !mediaPlaying else demoPlaying = !demoPlaying }
    fun nextTrack() = mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    fun prevTrack() = mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)

    // ---- super device ----
    private fun isConnected(d: BluetoothDevice) = try { d.javaClass.getMethod("isConnected").invoke(d) as Boolean } catch (_: Throwable) { false }

    private fun iconFor(d: BluetoothDevice): ImageVector = try {
        val c = d.bluetoothClass
        when (c?.majorDeviceClass) {
            BluetoothClass.Device.Major.AUDIO_VIDEO ->
                if (c.deviceClass == BluetoothClass.Device.AUDIO_VIDEO_LOUDSPEAKER) Icons.Rounded.Speaker else Icons.Rounded.Headphones
            BluetoothClass.Device.Major.PERIPHERAL -> Icons.Rounded.Keyboard
            BluetoothClass.Device.Major.COMPUTER -> Icons.Rounded.Laptop
            BluetoothClass.Device.Major.PHONE -> Icons.Rounded.Smartphone
            BluetoothClass.Device.Major.WEARABLE -> Icons.Rounded.Watch
            else -> Icons.Rounded.Bluetooth
        }
    } catch (_: Throwable) { Icons.Rounded.Bluetooth }

    private fun buildDevices(): List<DeviceInfo> {
        val real = try { if (hasBtPerm()) btAdapter?.bondedDevices?.toList().orEmpty() else emptyList() } catch (_: Throwable) { emptyList() }
        if (real.isNotEmpty()) {
            return real.map { d ->
                DeviceInfo(d.address, (try { d.name } catch (_: Throwable) { null }) ?: d.address, iconFor(d), isConnected(d)) { openBt() }
            }.sortedByDescending { it.active }.take(4)
        }
        fun demo(id: String, name: String, icon: ImageVector) = DeviceInfo(id, name, icon, id in demoActive) {
            demoActive = if (id in demoActive) demoActive - id else demoActive + id
            devices = buildDevices()
        }
        return listOf(
            demo("vision", "HUAWEI Vision", Icons.Rounded.Tv),
            demo("soundx", "Sound X", Icons.Rounded.Speaker),
            demo("buds", "HUAWEI FreeBuds 4", Icons.Rounded.Headphones)
        )
    }

    // ---- demo smart-home ----
    fun toggleCam() { camOn = !camOn; Prefs.setBool(ctx, "cam_on", camOn) }
    fun togglePurifier() { purifierOn = !purifierOn; Prefs.setBool(ctx, "purifier_on", purifierOn) }

    fun toggleScene(n: String) {
        val on = n !in scenes
        scenes = if (on) scenes + n else scenes - n
        Prefs.sp(ctx).edit().putStringSet("scenes", scenes).apply()
        when (n) {
            "Sleep" -> if (on) { setDnd(true); setEye(true, 0.6f) } else { setDnd(false); setEye(false, eyeStrength) }
            "Movie" -> if (on) { setDnd(true); setBrightness(0.25f) } else setDnd(false)
            "Happy Day" -> if (on) { setDnd(false); setEye(false, eyeStrength); setBrightness(0.7f) }
            "Home" -> if (on) setDnd(false)
        }
    }

    // ---- tile lists for the UI ----
    fun mainTiles(): List<TileModel> = listOf(
        TileModel("torch", "Flashlight", if (torch) Icons.Rounded.FlashlightOn else Icons.Rounded.FlashlightOff, torch, this::toggleTorch),
        TileModel("sound", "Sound",
            when (ringer) {
                AudioManager.RINGER_MODE_NORMAL -> Icons.Rounded.NotificationsActive
                AudioManager.RINGER_MODE_VIBRATE -> Icons.Rounded.Vibration
                else -> Icons.Rounded.NotificationsOff },
            ringer == AudioManager.RINGER_MODE_NORMAL, this::cycleRinger),
        TileModel("rotate", "Auto-rotate", Icons.Rounded.ScreenRotation, autoRotate, this::toggleRotation),
        TileModel("hotspot", "Hotspot", Icons.Rounded.WifiTethering, hotspot, this::openHotspot),
        TileModel("location", "Location", Icons.Rounded.LocationOn, location, this::toggleLocation),
        TileModel("airplane", "Airplane", Icons.Rounded.AirplanemodeActive, airplane, this::toggleAirplane)
    )

    fun extraTiles(): List<TileModel> = listOf(
        TileModel("dnd", "Do not disturb", Icons.Rounded.DoNotDisturbOn, dnd, this::toggleDnd),
        TileModel("nfc", "NFC", Icons.Rounded.Nfc, nfc, this::openNfc),
        TileModel("eye", "Eye comfort", Icons.Rounded.RemoveRedEye, eyeOn, this::toggleEye),
        TileModel("dark", "Dark mode", Icons.Rounded.DarkMode, dark, this::toggleDark),
        TileModel("data", "Mobile data", Icons.Rounded.SignalCellularAlt, dataOn, this::openData),
        TileModel("saver", "Power saving", Icons.Rounded.BatterySaver, saver, this::toggleSaver),
        TileModel("timeout", "Sleep ${timeoutLabel()}", Icons.Rounded.Timer, false, this::cycleTimeout),
        TileModel("autobright", "Auto bright", Icons.Rounded.BrightnessAuto, autoBright, this::toggleAutoBright),
        TileModel("lock", "Lock screen", Icons.Rounded.Lock, false, this::lockScreen),
        TileModel("shot", "Screenshot", Icons.Rounded.CropFree, false, this::screenshot),
        TileModel("power", "Power menu", Icons.Rounded.PowerSettingsNew, false, this::powerMenu),
        TileModel("camera", "Camera", Icons.Rounded.CameraAlt, false, this::openCamera)
    )
}
