@file:OptIn(ExperimentalFoundationApi::class)

package com.harmonyos.controlpanel

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val HmBlue = Color(0xFF0A59F7)

@Immutable
class Palette(val dark: Boolean, cardAlpha: Float = 0.64f) {
    val accent = HmBlue
    val card = (if (dark) Color(0xFF2A2B2F) else Color.White).copy(alpha = cardAlpha.coerceIn(0f, 1f))
    val stroke = if (dark) Color(0x14FFFFFF) else Color(0x66FFFFFF)
    val text = if (dark) Color(0xF2FFFFFF) else Color(0xE6000000)
    val sub = if (dark) Color(0x99FFFFFF) else Color(0x99000000)
    val tileOff = if (dark) Color(0x2EFFFFFF) else Color(0x1F000000)
    val iconOff = if (dark) Color(0xD9FFFFFF) else Color(0xCC4D4D4D)
    val track = if (dark) Color(0x33FFFFFF) else Color(0x29000000)
    val handle = if (dark) Color(0x66FFFFFF) else Color(0x40000000)
}

/** Springy press feedback (can be switched off in settings). */
@Composable
fun Modifier.pressScale(onClick: () -> Unit, onLong: (() -> Unit)? = null, target: Float = 0.94f): Modifier {
    val a = LocalAnim.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed && a.pressBounce && a.enabled) target else 1f,
        spring(dampingRatio = 0.5f, stiffness = 650f), label = "press"
    )
    val view = LocalView.current
    return this
        .graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(
            interactionSource = src, indication = null,
            onClick = {
                if (Haptics.enabled) view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                onClick()
            },
            onLongClick = onLong?.let { l ->
                {
                    if (Haptics.enabled) view.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                    l()
                }
            }
        )
}

/** Each part of the panel "sizes up" using the selected animation preset, staggered by [index]. */
@Composable
fun Modifier.popIn(shown: Boolean, index: Int): Modifier {
    val a = LocalAnim.current
    val p = remember(a.preset) { AnimPresets.get(a.preset) }
    val on = a.enabled
    val sp = a.speed.coerceIn(0.4f, 2.5f)
    val scale = remember { Animatable(if (on) p.scale0 else 1f) }
    val alpha = remember { Animatable(if (on) 0f else 1f) }
    val tx = remember { Animatable(if (on) p.tx0 else 0f) }
    val ty = remember { Animatable(if (on) p.ty0 else 0f) }
    LaunchedEffect(shown, on) {
        if (!on) return@LaunchedEffect
        if (shown) {
            delay((index * p.stagger / sp).toLong())
            val k = p.stiffness * sp * sp
            launch { scale.animateTo(1f, spring(dampingRatio = p.damping, stiffness = k)) }
            launch { ty.animateTo(0f, spring(dampingRatio = p.damping, stiffness = k)) }
            launch { tx.animateTo(0f, spring(dampingRatio = p.damping, stiffness = k)) }
            alpha.animateTo(1f, tween((280 / sp).toInt()))
        } else if (alpha.value > 0f) {
            val d = (220 / sp).toInt()
            launch { scale.animateTo(0.92f, tween(d)) }
            launch { ty.animateTo(-16f, tween(d)) }
            launch { tx.animateTo(0f, tween(d)) }
            alpha.animateTo(0f, tween(d))
        }
    }
    return this.graphicsLayer {
        scaleX = scale.value; scaleY = scale.value
        translationX = tx.value * density
        translationY = ty.value * density
        this.alpha = alpha.value
    }
}

@Composable
fun GlassCard(
    p: Palette,
    modifier: Modifier = Modifier,
    radius: Dp? = null,
    onClick: (() -> Unit)? = null,
    onLong: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val lay = LocalLayout.current
    val shape = RoundedCornerShape(radius ?: lay.radiusDp.dp)
    val m = if (onClick != null) modifier.pressScale(onClick, onLong, 0.97f) else modifier
    var look = Modifier.clip(shape).background(p.card)
    if (lay.outline) look = look.border(0.6.dp, p.stroke, shape)
    Box(m.then(look), content = content)
}

@Composable
fun CircleToggle(
    icon: ImageVector, active: Boolean, p: Palette,
    size: Dp = 46.dp, onClick: () -> Unit, onLong: (() -> Unit)? = null
) {
    val a = LocalAnim.current
    val ms = if (a.enabled) 240 else 0
    val bg by animateColorAsState(if (active) p.accent else p.tileOff, tween(ms), label = "bg")
    val tint by animateColorAsState(if (active) Color.White else p.iconOff, tween(ms), label = "tint")
    val pop = remember { Animatable(1f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(active) {
        if (first) { first = false } else if (a.enabled && a.toggleBounce) {
            pop.snapTo(0.82f); pop.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 420f))
        }
    }
    Box(
        Modifier.size(size).graphicsLayer { scaleX = pop.value; scaleY = pop.value }
            .pressScale(onClick, onLong, 0.88f).clip(CircleShape).background(bg),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.5f)) }
}

@Composable
fun IconTap(icon: ImageVector, tint: Color, onClick: () -> Unit, box: Dp = 34.dp, glyph: Dp = 20.dp) {
    Box(Modifier.size(box).pressScale(onClick, null, 0.85f), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(glyph))
    }
}

@Composable
fun HandleBar(p: Palette, onUp: () -> Unit, onDown: () -> Unit, onTap: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(22.dp)
            .pointerInput(Unit) { detectTapGestures { onTap() } }
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = 0f },
                    onDragEnd = { if (acc > 10f) onDown() else if (acc < -10f) onUp() }
                ) { c, dy -> c.consume(); acc += dy }
            },
        contentAlignment = Alignment.Center
    ) { Box(Modifier.size(18.dp, 3.dp).clip(CircleShape).background(p.handle)) }
}

@Composable
fun HmSlider(
    value: Float, onChange: (Float) -> Unit, p: Palette,
    startIcon: ImageVector, endIcon: ImageVector? = null, modifier: Modifier = Modifier
) {
    var drag by remember { mutableStateOf<Float?>(null) }
    var width by remember { mutableStateOf(1f) }
    var pressed by remember { mutableStateOf(false) }
    val shown = drag ?: value
    val v by animateFloatAsState(
        shown, if (drag != null) snap() else spring(stiffness = Spring.StiffnessMediumLow), label = "sv"
    )
    val thumb by animateFloatAsState(if (pressed) 1.22f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "th")
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(startIcon, null, tint = p.text.copy(alpha = 0.75f), modifier = Modifier.size(17.dp))
        Box(
            Modifier.weight(1f).height(30.dp).padding(horizontal = 8.dp)
                .onSizeChanged { width = it.width.toFloat().coerceAtLeast(1f) }
                .pointerInput(Unit) {
                    val r0 = 9.dp.toPx()
                    detectTapGestures(onPress = {
                        pressed = true
                        val f = ((it.x - r0) / (width - 2 * r0).coerceAtLeast(1f)).coerceIn(0f, 1f)
                        drag = f; onChange(f)
                        tryAwaitRelease()
                        pressed = false; drag = null
                    })
                }
                .pointerInput(Unit) {
                    val r0 = 9.dp.toPx()
                    detectHorizontalDragGestures(
                        onDragStart = { pressed = true },
                        onDragEnd = { pressed = false; drag = null },
                        onDragCancel = { pressed = false; drag = null }
                    ) { change, _ ->
                        change.consume()
                        val f = ((change.position.x - r0) / (width - 2 * r0).coerceAtLeast(1f)).coerceIn(0f, 1f)
                        drag = f; onChange(f)
                    }
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val h = 10.dp.toPx()
                val r0 = 9.dp.toPx()
                val r = r0 * thumb
                val cy = size.height / 2
                val x = r0 + (size.width - 2 * r0) * v
                drawRoundRect(p.track, Offset(0f, cy - h / 2), Size(size.width, h), CornerRadius(h / 2))
                drawRoundRect(p.accent, Offset(0f, cy - h / 2), Size(x + 2f, h), CornerRadius(h / 2))
                drawCircle(Color.White, r, Offset(x, cy))
                drawCircle(p.accent, r - 1.dp.toPx(), Offset(x, cy), style = Stroke(2.dp.toPx()))
            }
        }
        Icon(endIcon ?: startIcon, null, tint = p.text.copy(alpha = 0.75f), modifier = Modifier.size(if (endIcon != null) 20.dp else 17.dp))
    }
}
